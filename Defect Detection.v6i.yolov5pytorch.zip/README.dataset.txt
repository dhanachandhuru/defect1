# Defect Detection > 2023-03-20 12:40pm
https://universe.roboflow.com/dent-ydn9e/defect-detection-rhju6

Provided by a Roboflow user
License: CC BY 4.0

